class GraphNode
    attr_reader :value, :neighbors
  
    def initialize(value)
      @value = value
      @neighbors = []
    end
  
    def add_neighbor(neighbor_node)
      @neighbors << neighbor_node
    end

    def breadth_first_search(target_value)
        return self if self.value == target_value
    
        visited = Set.new
        queue = [self]
    
        until queue.empty?
          current_node = queue.shift
    
          if current_node.value == target_value
            return current_node
          end
    
          current_node.neighbors.each do |neighbor|
            unless visited.include?(neighbor)
              queue << neighbor
              visited.add(neighbor)
            end
          end
        end
    
        return nil
      end
  
    def to_s
      @value.to_s
    end
  end

  a = GraphNode.new('a')
b = GraphNode.new('b')
c = GraphNode.new('c')
d = GraphNode.new('d')
e = GraphNode.new('e')
f = GraphNode.new('f')
neighbors = [b, c, e]
neighbors = [b, d]
neighbors = [a]
neighbors = [e]