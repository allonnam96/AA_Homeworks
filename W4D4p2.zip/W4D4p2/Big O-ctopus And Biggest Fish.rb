def sluggish_octopus(fish_array)
    longest_fish = nil
  
    fish_array.each do |fish1|
      fish_array.each do |fish2|
        longest_fish = fish1 if fish1.length > fish2.length
      end
    end
  
    longest_fish
  end

  def dominant_octopus(fish_array)
    sorted_fish = fish_array.sort_by { |fish| fish.length }
    longest_fish = sorted_fish.last
  end

  def clever_octopus(fish_array)
    longest_fish = fish_array.first
  
    fish_array.each do |fish|
      longest_fish = fish if fish.length > longest_fish.length
    end
  
    longest_fish
  end

  def slow_dance(tile_direction, tiles_array)
    tiles_array.each_with_index do |tile, index|
      return index if tile == tile_direction
    end
    nil 
  end

  def fast_dance(tile_direction, tiles_hash)
    tiles_hash[tile_direction]
  end
  

  tiles_hash = {
    "up" => 0,
    "right-up" => 1,
    "right" => 2,
    "right-down" => 3,
    "down" => 4,
    "left-down" => 5,
    "left" => 6,
    "left-up" => 7
  }
  

  puts fast_dance("up", tiles_hash) # Output: 0
  puts fast_dance("right-down", tiles_hash) # Output: 3
  